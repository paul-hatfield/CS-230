# The Gaming Room

## Summary

### The Gaming Room wanted a multi-client gaming application. The client ranged from mobile devices like Android, to desktop clients like Windows. Analyzing the requirements in a step by step basis helped in breaking down the scope of the project into individual modules, classes, etc. This in-depth approach also helped in understanding the user’s needs and making sure they were included in project solution. In the future, I would think being more descriptive in documentation would greatly increase my skills and project outcomes.
